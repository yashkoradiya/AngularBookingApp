import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SharedService {
  readonly APIUrl ="https://localhost:7116/api";


  constructor(private http : HttpClient) { }

  getUserDetailsList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/UserDetails');
  }

  AddDetails(val:any){
    return this.http.post<any>(this.APIUrl+'/UserDetails',val);
  }

  UpdateDetails(val:any){
    return this.http.put<any>(this.APIUrl+'/UserDetails',val);
  }

  DeleteDetails(val:any){
    return this.http.delete<any>(this.APIUrl+'/UserDetails'+val);
  }


  getEventDetailsList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/EventDetails');
  }

  AddEventDetails(val:any){
    return this.http.post<any>(this.APIUrl+ '/EventDetails',val);
  }

  UpdateEventDetails(val:any){
    return this.http.put<any>(this.APIUrl+ '/EventDetails',val);
  }

  DeleteEventDetails(val:any){
    return this.http.delete<any>(this.APIUrl+ '/EventDetails'+val);
  }

}
