import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-evnt-det',
  templateUrl: './show-evnt-det.component.html',
  styleUrls: ['./show-evnt-det.component.css']
})
export class ShowEvntDetComponent implements OnInit {

  constructor() { }

 

  ngOnInit(): void {
  }

}
