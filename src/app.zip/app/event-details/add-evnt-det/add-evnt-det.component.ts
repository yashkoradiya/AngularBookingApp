import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-evnt-det',
  templateUrl: './add-evnt-det.component.html',
  styleUrls: ['./add-evnt-det.component.css']
})
export class AddEvntDetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
