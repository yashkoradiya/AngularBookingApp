import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-details',
  templateUrl: './show-details.component.html',
  styleUrls: ['./show-details.component.css']
})
export class ShowDetailsComponent implements OnInit {

  constructor(private service: SharedService) { }
  UserDetailsList !: any[];

  ngOnInit(): void {

    this.refreshUserList();
  }


  refreshUserList(){
    this.service.getUserDetailsList().subscribe(data=>{
      this.UserDetailsList=data;
    });

}
}
