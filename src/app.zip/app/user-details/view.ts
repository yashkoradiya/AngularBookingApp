export interface UserDetails{
    userId: number;
    userUserName: string;
    userContact: number;
    userGender: string;
  }